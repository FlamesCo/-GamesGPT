
import pygame

# Initialize the pygame
pygame.init()

# Create the screen
screen = pygame.display.set_mode((400, 300))

# Title and Icon
pygame.display.set_caption("Pong")

# Score
score_a = 0
score_b = 0

# Paddle A
paddle_a = pygame.Rect(20, 150, 15, 100)

# Paddle B
paddle_b = pygame.Rect(365, 150, 15, 100)

# Ball
ball = pygame.Rect(200, 150, 15, 15)

# Speed of the ball
ball_velocity_x = 3
ball_velocity_y = 3

# Movement of the paddles
paddle_a_velocity = 0
paddle_b_velocity = 0

# Main loop
running = True
while running:
    # Handling input
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # Handling keyboard input
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                paddle_b_velocity -= 2
            if event.key == pygame.K_DOWN:
                paddle_b_velocity += 2
            if event.key == pygame.K_w:
                paddle_a_velocity -= 2
            if event.key == pygame.K_s:
                paddle_a_velocity += 2
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                paddle_b_velocity = 0
            if event.key == pygame.K_w or event.key == pygame.K_s:
                paddle_a_velocity = 0

    # Update the paddles
    paddle_a.y += paddle_a_velocity
    paddle_b.y += paddle_b_velocity

    # Keeping the paddles in bounds
    if paddle_a.y < 0:
        paddle_a.y = 0
    if paddle_a.y > 200:
        paddle_a.y = 200
    if paddle_b.y < 0:
        paddle_b.y = 0
    if paddle_b.y > 200:
        paddle_b.y = 200

    # Update the ball
    ball.x += ball_velocity_x
    ball.y += ball_velocity_y

    # Bounce the ball off the walls
    if ball.y < 0 or ball.y > 285:
        ball_velocity_y *= -1
    if ball.x < 0:
        score_b += 1
        ball = pygame.Rect(200, 150, 15, 15)
    if ball.x > 385:
        score_a += 1
        ball = pygame.Rect(200, 150, 15, 15)

    # Bounce the ball off the paddles
    if ball.colliderect(paddle_a) or ball.colliderect(paddle_b):
        ball_velocity_x *= -1

    # Draw everything
    screen.fill((0, 0, 0))
    pygame.draw.rect(screen, (255, 255, 255), paddle_a)
    pygame.draw.rect(screen, (255, 255, 255), paddle_b)
    pygame.draw.rect(screen, (255, 255, 255), ball)
    pygame.draw.line(screen, (255, 255, 255), (195, 0), (195, 300), 5)
    pygame.display.flip()

pygame.quit()
