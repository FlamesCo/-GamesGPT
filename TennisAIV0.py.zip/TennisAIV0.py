import pygame
import random
import sys

# Initialize Pygame
pygame.init()

# Set up the game window
screen = pygame.display.set_mode((400, 300))
pygame.display.set_caption("Tennis for Two Volume AI 0.A")

# Set up the game objects
ball = pygame.Rect(200, 150, 10, 10)
paddle1 = pygame.Rect(0, 125, 10, 50)
paddle2 = pygame.Rect(390, 125, 10, 50)

# Set up the game variables
ball_speed_x = 2 * random.choice((1, -1))
ball_speed_y = 2 * random.choice((1, -1))
paddle_speed = 5

# Set up the game loop
while True:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Move the ball
    ball.x += ball_speed_x
    ball.y += ball_speed_y

    # Bounce the ball off the walls and paddles
    if ball.top < 0 or ball.bottom > 300:
        ball_speed_y *= -1
    if ball.left < 0 or ball.right > 400:
        ball_speed_x *= -1
    if ball.colliderect(paddle1) or ball.colliderect(paddle2):
        ball_speed_x *= -1

    # Move the paddles
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]:
        paddle1.y -= paddle_speed
    if keys[pygame.K_s]:
        paddle1.y += paddle_speed
    if keys[pygame.K_UP]:
        paddle2.y -= paddle_speed
    if keys[pygame.K_DOWN]:
        paddle2.y += paddle_speed

    # Keep the paddles inside the screen boundaries
    if paddle1.top < 0:
        paddle1.top = 0
    if paddle1.bottom > 300:
        paddle1.bottom = 300
    if paddle2.top < 0:
        paddle2.top = 0
    if paddle2.bottom > 300:
        paddle2.bottom = 300

    # Draw the game objects
    screen.fill((255, 255, 255))
    pygame.draw.rect(screen, (0, 0, 0), ball)
    pygame.draw.rect(screen, (0, 0, 0), paddle1)
    pygame.draw.rect(screen, (0, 0, 0), paddle2)

    # Update the display
    pygame.display.update()

    # Add a delay to slow down the game
    pygame.time.wait(10)
